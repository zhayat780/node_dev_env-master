# node_dev_env
A NodeJS starter environment, including the NGX Rocket application  
Use this repository as reference for **Creating a Base Box**
